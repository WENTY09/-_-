# Telegram Bot Package initialization
from telegram_bot.bot import run_telegram_bot

__all__ = ['run_telegram_bot']