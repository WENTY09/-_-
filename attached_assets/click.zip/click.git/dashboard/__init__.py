"""
Dashboard package initialization
"""